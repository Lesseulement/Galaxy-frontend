import { configureStore } from '@reduxjs/toolkit'
import authReducer from './authSlice'
import filterReducer from './filterSlice'
import galaxiesReducer from './galaxiesSlice'

// Хранилище Redux Toolkit: redux-thunk и Redux DevTools подключаются configureStore автоматически
export const store = configureStore({
  reducer: {
    auth: authReducer,         // интерфейс гостя / пользователя
    filter: filterReducer,     // фильтр плитки
    galaxies: galaxiesReducer, // галактики: плитка, лента, черновик
  },
})

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
